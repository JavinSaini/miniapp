module.exports = function(app, siteData) {

    const redirectLogin = (req, res, next) => {
        if (!req.session.loggedin) {
            res.redirect('/login');
        } else {
            next();
        }
    };
    
    //Required modules
    const fetch = require('node-fetch');
    const bcrypt = require('bcrypt');
    const request = require('request');

    //calling quote api
    const options = {
      method: 'GET',
      url: 'https://quotes15.p.rapidapi.com/quotes/random/',
      headers: {
        'X-RapidAPI-Key': 'f0c1108d6fmsh66c3959c25f7540p1061aajsn4418a39208dc',
        'X-RapidAPI-Host': 'quotes15.p.rapidapi.com'
      }
    };
    
    request(options, function (error, response, body) {
        if (error) throw new Error(error);
    
        console.log(body);
        console.log(response.content);
    });
    
    app.get('/quote', async (req, res) => {
        const options = {
            method: 'GET',
            url: 'https://quotes15.p.rapidapi.com/quotes/random/',
            headers: {
                'X-RapidAPI-Key': 'f0c1108d6fmsh66c3959c25f7540p1061aajsn4418a39208dc',
                'X-RapidAPI-Host': 'quotes15.p.rapidapi.com'
            }
        };
    
        try {
            const response = await fetch(options.url, { headers: options.headers });
            const quoteData = await response.json();
            res.render('quote.ejs', { quote: quoteData.content }); // Assuming you have a quote.ejs file
        } catch (error) {
            console.error(error);
            res.send('Error fetching quote');
        }
    });

    app.get('/',function(req,res){
        res.render('index.ejs', siteData)
    });
    app.get('/about',function(req,res){
        res.render('about.ejs', siteData);
    });
    app.get('/search', (req, res) => {
        if (req.session.loggedin) {
            // User is logged in, render the search page
            res.render("search.ejs", siteData);
        } else {
            // User is not logged in, redirect to the login page
            res.redirect('/login');
        }
    });
    
    //search option, selecting from list
    app.get('/search-result', redirectLogin, function (req, res) {
        let sqlquery = "SELECT * FROM gears WHERE name LIKE '%" + req.query.keyword + "%'";
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.redirect('./'); 
            } else {
                let newData = Object.assign({}, siteData, {availableGears: result});
                res.render("list.ejs", { loggedIn: req.session.loggedin, ...newData });
            }
        });        
    });
    
    app.get('/register', function (req,res) {
        res.render('register.ejs', siteData);                                                                     
    });                                                                                                 
    app.post('/registered', async (req, res) => {
        const { username, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10); // Hashing the password
    
        const sql = 'INSERT INTO users (username, hashed_password) VALUES (?, ?)';
        db.query(sql, [username, hashedPassword], (err, result) => {
            if (err) {
                // Handle the error (e.g., user already exists, database error)
                res.redirect('/register?error=Registration failed');
            } else {
                // Redirect to login page after successful registration
                res.redirect('/login');
            }
        });
    });
     

    app.get('/login', function(req, res) {
        // Check if there's an error message to display
        const errorMessage = req.query.error;

        // Render the login.ejs template
        res.render('login.ejs', { errorMessage: errorMessage });
    });

        //Login function, read user from database and compare
    app.post('/login', async function(req, res) {
        const { username, password } = req.body;
    
        if (username && password) {
            const sql = "SELECT * FROM users WHERE username = ?";
            db.query(sql, [username], async (err, results) => {
                if (err) {
                    console.error(err);
                    res.redirect('/login?error=Login error');
                    return;
                }
    
                if (results.length > 0) {
                    const user = results[0];
                    const match = await bcrypt.compare(password, user.hashed_password);
                    if (match) {
                        req.session.loggedin = true;
                        req.session.username = username;
                        res.redirect('/');
                    } else {
                        res.send('Incorrect Username and/or Password!');
                    }
                } else {
                    res.send('User not found');
                }
            });
        } else {
            res.send('Please enter Username and Password!');
        }
    });
    


    

    app.get('/logout', redirectLogin, (req,res) => {
        req.session.destroy(err => {
        if (err) {
          return res.redirect('./')
        }
        res.send('you are now logged out. <a href='+'./'+'>Home</a>');
        })
    })

    app.get('/list', function(req, res) {
        if (req.session.loggedin) {
            let sqlquery = "SELECT * FROM gears"; 
            db.query(sqlquery, (err, result) => {
                if (err) {
                    res.redirect('./'); 
                } else {
                    let newData = Object.assign({}, siteData, { availableGears: result });
                    res.render("list.ejs", { loggedIn: req.session.loggedin, ...newData });
                }
            });
        } else {
            res.redirect('/login');
        }
    });
    app.post('/logout', (req, res) => {
        req.session.destroy(err => {
            if (err) {
                return res.redirect('/');
            }
            res.redirect('/login');
        });
    });

    app.get('/api', function (req,res) {

        // Query database to get all the gears
        let sqlquery = "SELECT * FROM gears"; 

        // Execute the sql query
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.redirect('./');
            }
            // Return results as a JSON object
            res.json(result); 
        });
    });

    
    
    
}