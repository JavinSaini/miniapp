DROP DATABASE mysportsgear;
CREATE DATABASE mySportsgear;
USE mySportsgear;

CREATE TABLE users (
    id INT AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE,
    hashed_password VARCHAR(255),
    PRIMARY KEY(id)
);

INSERT INTO users (username, hashed_password) VALUES ('?', '?');


CREATE TABLE gears (
    id INT AUTO_INCREMENT,
    name VARCHAR(50),
    price DECIMAL(5, 2),
    PRIMARY KEY(id)
);

INSERT INTO gears (name, price) VALUES
    ('Baseball Bat', 60.75),
    ('Football Shoes', 45.50),
    ('Boxing Gloves', 32.50),
    ('Tennis Racket', 85.00),
    ('Golf Clubs', 120.00),
    ('Basketball', 30.00),
    ('Cycling Helmet', 40.00),
    ('Ski Goggles', 55.00),
    ('Yoga Mat', 20.00),
    ('Swimming Goggles', 15.00);

    
CREATE USER 'appuser'@'localhost' IDENTIFIED WITH mysql_native_password BY 'app2027';
GRANT ALL PRIVILEGES ON mySportsgear.* TO 'appuser'@'localhost';


